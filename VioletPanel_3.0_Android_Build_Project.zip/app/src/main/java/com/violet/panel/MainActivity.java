package com.violet.panel;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 6, 17);
    private final int CARD = Color.rgb(24, 15, 39);
    private final int PURPLE = Color.rgb(181, 108, 255);
    private TextView state;
    private Button startStop;
    private Switch esp, aim, smooth;

    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (stroke > 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout panel(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 16, 18, 16);
        box.setBackground(bg(CARD, 22, Color.rgb(75, 42, 112)));
        box.addView(label(title, 17, Color.WHITE, true));
        TextView hint = label(subtitle, 12, Color.rgb(177,160,198), false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = 5;
        box.addView(hint, hp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 9, 0, 9);
        box.setLayoutParams(lp);
        return box;
    }

    private Switch addToggle(LinearLayout parent, String title, String detail) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.addView(label(title, 15, Color.WHITE, true));
        words.addView(label(detail, 11, Color.rgb(177,160,198), false));
        row.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        row.addView(sw);
        parent.addView(row);
        return sw;
    }

    private void setRunning(boolean running) {
        state.setText(running ? "●  PANEL ACTIVE" : "●  STOPPED");
        state.setTextColor(running ? Color.rgb(135,255,190) : Color.rgb(255,120,160));
        startStop.setText(running ? "STOP PANEL" : "START PANEL");
        startStop.setTag(running);
    }

    private void stopAll() {
        esp.setChecked(false);
        aim.setChecked(false);
        smooth.setChecked(false);
        setRunning(false);
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 26, 20, 24);
        scroll.addView(root);

        root.addView(label("VIOLET / PANEL", 26, PURPLE, true));
        TextView version = label("VERSION 3.0  •  ANDROID", 10, Color.rgb(184,164,207), true);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = 5; vp.bottomMargin = 18;
        root.addView(version, vp);

        LinearLayout privacy = panel("PRIVACY & SAFETY", "Standalone offline interface");
        privacy.addView(label("✓ No internet permission\n✓ No root access\n✓ No game injection or modification\n✓ No overlay or accessibility access\n✓ No data collection", 12, Color.rgb(190,225,202), false));
        root.addView(privacy);

        LinearLayout features = panel("DEMO FEATURES", "Эти переключатели меняют только этот экран");
        esp = addToggle(features, "ESP Preview", "Визуальная демонстрация");
        View line1 = new View(this);
        line1.setBackgroundColor(Color.rgb(67,45,87));
        features.addView(line1, new LinearLayout.LayoutParams(-1, 1));
        aim = addToggle(features, "AimDrag Demo", "Не управляет игровым прицелом");
        View line2 = new View(this);
        line2.setBackgroundColor(Color.rgb(67,45,87));
        features.addView(line2, new LinearLayout.LayoutParams(-1, 1));
        smooth = addToggle(features, "Smooth Aim Demo", "Только настройка интерфейса");
        root.addView(features);

        LinearLayout settings = panel("SENSITIVITY", "Demo slider");
        SeekBar slider = new SeekBar(this);
        slider.setMax(100);
        slider.setProgress(50);
        TextView amount = label("50 / 100", 12, PURPLE, true);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                amount.setText(value + " / 100");
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) {}
        });
        settings.addView(slider);
        settings.addView(amount);
        root.addView(settings);

        LinearLayout controls = panel("CONTROL", "Controls this demo panel only");
        state = label("●  STOPPED", 13, Color.rgb(255,120,160), true);
        controls.addView(state);

        startStop = new Button(this);
        startStop.setText("START PANEL");
        startStop.setTextColor(Color.WHITE);
        startStop.setAllCaps(false);
        startStop.setBackground(bg(Color.rgb(112,55,174), 18, PURPLE));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 12;
        controls.addView(startStop, bp);
        startStop.setOnClickListener(v -> setRunning(!Boolean.TRUE.equals(startStop.getTag())));

        Button emergency = new Button(this);
        emergency.setText("EMERGENCY STOP");
        emergency.setTextColor(Color.WHITE);
        emergency.setAllCaps(false);
        emergency.setBackground(bg(Color.rgb(91,32,65), 18, Color.rgb(255,120,160)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = 8;
        controls.addView(emergency, ep);
        emergency.setOnClickListener(v -> stopAll());
        root.addView(controls);

        TextView disclaimer = label("Demo app only. It does not interact with Free Fire or guarantee protection from game bans.", 11, Color.rgb(180,160,190), false);
        disclaimer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = 15;
        root.addView(disclaimer, dp);

        setContentView(scroll);
        setRunning(false);
    }
}
